import { Outlet } from "react-router";

import Navbar from "./Navbar";
import Sidebar from "./Sidebar";

export default function DashboardLayout() {
  return (
    <>
      <Navbar />

      <Sidebar />
      <div className="flex">
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </>
  );
}
