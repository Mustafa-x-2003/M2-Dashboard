import React from "react";
import { Link } from "react-router";
import { useAuth } from "../../context/AuthContext";

function Sidebar() {
  const { logout } = useAuth();

  return (
    <div>
      <ul className="bg-amber-100 w-full flex fixed top-0 justify-center">
        <div className="flex items-center justify-between gap-10 text-4xl">
          <li><Link to="dashboard">Dashboard</Link></li>
          <li><Link to="products">Products</Link></li>
          <li><Link to="orders">Orders</Link></li>
          <li><Link to="users">Users</Link></li>
        </div>

        <button onClick={logout}>Logout</button>
      </ul>
    </div>
  );
}

export default Sidebar;
