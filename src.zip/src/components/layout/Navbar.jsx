import React from 'react'

function Navbar() {
  return (
    <div>
      <h1>my header</h1>
    </div>
  )
}

export default Navbar
